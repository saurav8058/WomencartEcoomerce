# Filter Sidebar Accordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/robatgrailed/pen/mYyRwo](https://codepen.io/robatgrailed/pen/mYyRwo).

